# Running the test suite

The unit tests are built upon the following tools:

- Mocha -- the underlying test suite which executes the test and reports feedback
- node.js -- used for testing at the command line, via the `mocha` package

To run the unit tests run the following command:

    npm run test
